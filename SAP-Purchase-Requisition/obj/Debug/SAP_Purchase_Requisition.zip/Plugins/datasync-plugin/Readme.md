# Telerik DataSync Cordova Plugin


**DataSync** object -  The object used for all ORM & synchronization functionality.
 
 
## Usage
 
###Step 1. Create a context

//Here is how to initialize the data sync context to work with a custom OData service:
	
	var endpointsForEntities = { TKTask 	 : {
			TK_ANY : 'https://sapes1.sapdevcenter.com/sap/opu/odata/sap/ZCD204_EPM_DEMO_SRV/',
		 	TK_CREATE : 'https://sapes1.sapdevcenter.com/sap/opu/odata/sap/ZCD204_EPM_DEMO_SRV/'},
	 	TKSalesOrder : {	
	 		TK_ANY : 'https://sapes1.sapdevcenter.com/sap/opu/odata/sap/ZCD204_EPM_DEMO_SRV/',
	 		TK_READ : 'https://sapes1.sapdevcenter.com/sap/opu/odata/sap/ZCD204_EPM_DEMO_SRV/',                                        
	 		TK_UPDATE : 'https://sapes1.sapdevcenter.com/sap/opu/odata/sap/ZCD204_EPM_DEMO_SRV/',
	 		TK_DELETE : 'https://sapes1.sapdevcenter.com/sap/opu/odata/sap/ZCD204_EPM_DEMO_SRV/'} };

	var mapping = {	TKTask : 'TKTasks' ,
               	SyncLock : 'SyncLocks'};
                              
	var typeMapping = { TKTask   : 'TKTasksService.TKTasks',
					SyncLock  : 'TKTasksService.SyncLocks'};
    
	var systemFieldsMapping = { CreatedAt : 'CreatedAt',
                           ModifiedAt : 'ChangedAt'};
                                          
	dataSync.createContext({ProviderName:'MyODataService',
                            LocalDatabaseName:'localDB',
                            Username:'andy',
                            Password:'password1',
                            EntityPointsMap: endpointsForEntities,
                            Mapping : mapping,
                            TypeMapping : typeMapping,
                            SystemFieldsMapping : systemFieldsMapping
                           },
                           
                           
                                                       
  
  
//just FYI and not needed for the current purposes: initialization of data sync context to work with Everlive backend

	dataSync.createContext({ ProviderName:"Everlive",
								LocalDatabaseName:'localDB',
								ApiKey:'bsRwaaaaaaaa’,
								Username:'andy',
								Password:'password1',
								ApiVersion: 1 });
 
###Step 2. Register entity & primary key
	
	dataSync.registerClass({ EntityName:'Task',
							PrimaryKeyName: 'productId',
							PropertyValues: { 	productId: ‘String',
							title: 'String',
							details: ‘String' } 
							});
###Step 3. CRUD operations
 
// Get all objects of model “Task”

	dataSync.allObjects({EntityName: 'Task'}, function success(result) {});
 
//Fetch objects with query

	dataSync.addObject({ EntityName:'Task',
						Query:’Select * from Task where title like “B*” ’},
                   	 	function success() {},
                   	 	function error() {});
 
//Insert a new object

	dataSync.addObject({ EntityName:'Task',
						PropertyValues:{ productId: 234, title: “abadaba”, details: “some info”}},
                   	 	function success() {},	
                   	 	function error() {});
 
 
//Update an object

	dataSync.updateObject({ EntityName: 'Task',
							PropertyValues: :{ productId: 234, title: “abadaba”, details: “some info”}},
							function success() {},
							function error() {});
 
//Delete an object

	dataSync.deleteObject({ EntityName: 'Task',
							PrimaryKeyName: 'productId',
							PropertyValues: item.productId}, // value of primary key field
							function success() {},
							function error() {});
 
//Synchronize the accumulated changes 

	dataSync.syncChanges(function success () {}, function error() {});
 
 // Since the dataSync objects works as a repository for your object chagnes and keeps all changes in memory, at any suitable moment of application execution you have to call **saveChanges()** function in order to persist the accumulated changes in database. 

	dataSync.saveChanges(function success () {}, function error() {});
	
## Api reference

**DataSync object**

The parameter named "options" keeps the input values, that the function require, as a key-value list. All methods rely on this parameter.

//Initialize the dataSync object with a context that will be used for offline data persistence only.

    createOfflineContext = function (options, success, fail)
    createOfflineContextAsync = function (options, success, fail)
 
//Initialize the dataSync object with fully featured data sync context object. Fully featured meaning that it can be used for local data persistence and for synchronization as well. 

 	createContext = function (options, success, fail)
	createContextAsync = function (options, success, fail)

//The OData initialization requires a JSON data in the following format:

	{
		ProviderName : <string> 	// everything different from ‘Everlive’ will be treated as OData client
		Username : <string> 		//the username for connection
		Password : <string> 		//the user password
		LocalDatabaseName : <string>	//the name of the local db file
		EntityPointsMap : <dictionary> 		// dictionary with endpoints for CRUD operations in format:
			 							{ model_name -> {CRUD_operation -> endpoint_URI , …. } …. }
		Mappping : <dictionary> 		// the mapping of entity class names to backend collection names
		TypeMapping : <dictionary> 		//the mapping of entity class names to backend type names 
		SystemFieldsMapping : <dictionary> //the mapping of system fields to corresponding fields on the backend tables. 
											  ex: ModifiedAt can be mapped to Z_ChangedAt
		SyncConflictResolutionType : <string> 	// Optional. If not specified as follows the local item overwrites the remote item. 
		//Use 'PreferRemoteInstance' value if you want changes applied to backend item to overvrite the local changes.
		Use 'CustomConflictResolution' to implement custom item merge logic as it is described in section Event Handlers									  
	}

 
//The Everlive initialization requires JSON data in the following format:

	{ 
		ProviderName:"Everlive", 	//everything different from Everlive will be treated as OData client 
		LocalDatabaseName:<string>,	//the name of database file
        ApiKey:<string>, 			//the api key for given TBaaS application
	 	Username:<string>, 			//the user name
        Password:<string>, 			//the user password
        ApiVersion: 1  				//the api version , only version 1 is accepted for now
        SyncConflictResolutionType : <string> //as for OData above
	}


//Initiate a synchronization process.
 
 	syncChanges = function (success, fail)
 	syncChangesAsync = function (success, fail)

//Persist accumulated chages in database file.
  	
  	saveChanges = function(options, success, fail)
  	saveChangesAsync = function(options, success, fail)
  	
//Initiate synchronization of one model/table only.
  	
  	syncModel = function(options, success, fail)
 
//Register a class as it is described in the options parameter.
  
  	registerClass = function (options, success, fail)
    this.registerClassAsync = function (options, success, fail)

//A property to check if the latest changes are synchronized with the backend.
	
	isSynced : boolean
 
//Add an object described as a key-value JSON.
 
 	addObject = function (options, success, fail)
 
//Update an existing object.

	updateObject = function (options, success, fail)
 
//Delete a given object from database.
 
 	deleteObject = function (options, success, fail)
 
//Fetches all objects of given type name.

	allObjects = function (options, success, fail)
 
//Fetches objects with SQL query from the local database.

	objectsWithQuery = function (options, success, fail)

//Registers event handler for supported events  
	
	registerHandler = function(type, handler)
 
 //Unregister event handler for supported events
 
 	unregisterHandler = function(type, handler)
    
 
##  Event handling

You can register handlers for some events fired during the synchronization process. In this way you can add custom logic to synchronization process and do custom conflict resolution of items changed localy and remotely. 

Events:

**isContextReadyForSynchronization** - called before synchronization procedure. Use it to check the application state and decide if the synchronization process should be done or not. 

Return *true* if the synchronization procedure should continue, or *false* to cancel it.
	
**dataSyncFailedForTableWithName** - called if the synchronization for table with given name as param1 has failed. 

Handler function is called with one string parameter for table name.

Return *true* if you wnat to synchronize table changes again during current synchronization process, else *false* to postpone it for next synchronization attempt.

**beforeSynchOfTableWithName** - called before the synchronization of table with given name begins. 

Handler function is called with one string parameter for table name.

Return *true* if you wish this table to be synchronized, else *false* to avoid this table

**afterSynchOfTableWithName** - called after the successful synchronization of table with given name. 

Handler function is called with one string parameter for table name.

Return *true/false* according to the success state of post processing.

**resolveConflictOfObjects** - Use to resolves conflict between given remote and local instances of the same item of given type. 
Handler function is called with 3 parameters: 
	
	'typeName' - string with the table name 
	'remoteObjJSON' - string with JSON representation of remote instance of object
	'localObjJSON' - string with JSON representation of local instance of object

If any of object parameters is null then this item is deleted and you should decide if to return an emtpy JSON sring as resolution or the another instance.
Returns a JSON representation of resolution object.

NOTE: this method is called only in case of **SyncConflictResolutionType** set to *'CustomConflictResolution'* and must be handled for this case, error will be thrown otherwise.
 
 For more information how to use this plugin with different development evironments see the How-to section in [WIKI] (https://github.com/telerik/DataSync/wiki) page.

##  SQLCipher notes
 
 Cordova plugin uses SQLCipher for local db encryption by default. Currently there is not a way to avoid SQLCipher.
 
 In order to user the plugin for Android hybrid solutions you should add the *icudt46l.zip* file to *assets* folder of solution. Find the file in *Cordova/datasync-plugin/src/android/SQLCipherLib/assets/* folder
