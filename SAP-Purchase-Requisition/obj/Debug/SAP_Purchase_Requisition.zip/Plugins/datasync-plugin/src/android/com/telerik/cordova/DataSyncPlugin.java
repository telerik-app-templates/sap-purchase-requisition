package com.telerik.cordova;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.PluginResult;
import org.apache.cordova.PluginResult.Status;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.TargetApi;
import android.os.Build;
import android.webkit.ValueCallback;

import com.google.dexmaker.DexMaker;
import com.telerik.android.common.serialization.JSONHelper;
import com.telerik.widget.datasync.cloud.CloudClient;
import com.telerik.widget.datasync.cloud.CloudEntityMapper;
import com.telerik.widget.datasync.cloud.SynchronizationException;
import com.telerik.widget.datasync.cloud.implementations.everlive.EverliveCloudClient;
import com.telerik.widget.datasync.cloud.implementations.odata.ODataClient;
import com.telerik.widget.datasync.cloud.implementations.odata.ODataCredential;
import com.telerik.widget.datasync.dynamic.TypeInfo;
import com.telerik.widget.datasync.dynamic.TypeStructureGeneratorContext;
import com.telerik.widget.datasync.syncengine.DataSyncContext;
import com.telerik.widget.datasync.syncengine.DataSyncDelegate;
import com.telerik.widget.datasync.syncengine.DataSyncPolicy;
import com.telerik.widget.datasync.syncengine.DataSyncReachabilityOptions;
import com.telerik.widget.datasync.syncengine.DataSyncResolutionType;
import com.telerik.widget.datasync.syncengine.DataSyncType;
import com.telerik.widget.datasync.syncengine.EntityTypeResolver;

public class DataSyncPlugin extends CordovaPlugin implements DataSyncDelegate{
    private CallbackContext callbackContext;
    private DataSyncContext dataSyncContext;
    private TypeStructureGeneratorContext dynamicClassGenerator;

    private static final String PROVIDER_PROPERTY_KEY = "ProviderName";
    private static final String HOSTNAME_PROPERTY_KEY = "ProviderHostName";
    private static final String API_KEY_PROPERTY_KEY = "ApiKey";
    private static final String API_VERSION_PROPERTY_KEY = "ApiVersion";
    private static final String USERNAME_PROPERTY_KEY = "Username";
    private static final String PASSWORD_PROPERTY_KEY = "Password";
    
    private static final String LOCAL_DATABASE_PROPERTY_KEY = "LocalDatabaseName";
    private static final String DATA_SYNC_TYPE_PROPERTY_KEY = "DataSyncType";
    private static final String DATA_CONFLICT_RESOLUTION_TYPE_PROPERTY_KEY = "SyncConflictResolutionType";
    private static final String DATA_SYNC_TIMEOUT_PROPERTY_KEY = "DataSyncTimeout";
    private static final String DATA_SYNC_TIME_INTERVAL_PROPERTY_KEY = "DataSyncTimeInterval";
    private static final String DATA_SYNC_REACHABILITY_PROPERTY_KEY = "DataSyncReachability";

    private static final String ENTITY_NAME_ARGUMENT_KEY = "EntityName";
    private static final String PRIMARY_KEY_NAME_ARGUMENT_KEY = "PrimaryKeyName";
    private static final String QUERY_ARGUMENT_KEY = "Query";
    private static final String PROPERTY_VALUES_ARGUMENT_KEY = "PropertyValues";
    private static final String PRIMARY_KEY_AUTO_INCREMENT = "PrimaryKeyAutoIncrement";

    private static final String MULTIPLE_POINTS_MAP_ARGUMENT_KEY = "EntityPointsMap";
    private static final String MAPPING_ARGUMENT_KEY = "Mapping";
    private static final String TYPE_MAPPING_ARGUMENT_KEY = "TypeMapping";
    private static final String SYSTEM_FIELDS_MAPPING_ARGUMENT_KEY = "SystemFieldsMapping";

    private static final int CREATE = 1;
    private static final int READ = 2;
    private static final int UPDATE = 3;
    private static final int DELETE = 4;

    public DataSyncPlugin() {
    }

    @Override
    public void initialize(CordovaInterface cordova, CordovaWebView webView) {
        // call super's initialize to ensure compatibility with older Cordova
        // versions
        super.initialize(cordova, webView);

        // Initialize the dynamic class generator and pass it to the class
        // generator engine.
        DexMaker dexMaker = new DexMaker();
        this.dynamicClassGenerator = new TypeStructureGeneratorContext(cordova.getActivity(), dexMaker);

        // We do this to make sure any generated .jar files with dynamic types
        // are preliminary loaded to optimize performance.
        this.dynamicClassGenerator.preLoadTypesCache();
    }

    private void sendResult(Status exStatus, String theMessage) {
        PluginResult pResult = new PluginResult(exStatus, theMessage);
        this.callbackContext.sendPluginResult(pResult);
    }

    private void sendResult(Status exStatus, JSONArray objects) {
        PluginResult pResult = new PluginResult(exStatus, objects);
        this.callbackContext.sendPluginResult(pResult);
    }

    @Override
    public boolean execute(String action, final JSONArray args, final CallbackContext callbackContext)
            throws JSONException {
        // TODO Auto-generated method stub
        this.callbackContext = callbackContext;

        try {
            if ("createContext".equals(action)) {
                createContext(args);
                sendResult(Status.OK, "Context created successfully");
            } else if ("createContextAsync".equals(action)) {
                cordova.getThreadPool().execute(new Runnable() {
                    public void run() {
                        try {
                            createContext(args);
                            sendResult(Status.OK, "Context created successfully");
                        } catch (JSONException e) {
                            sendResult(Status.JSON_EXCEPTION, e.getMessage());
                        }
                    }
                });
            } else if ("saveChanges".equals(action)) {
                if (this.dataSyncContext.saveChanges()) {
                    sendResult(Status.OK, "Changes saved successfully");
                } else {
                    sendResult(Status.ERROR, "Could not save changes. Reason unknown.");
                }
            } else if ("saveChangesAsync".equals(action)) {
                final DataSyncContext dsc = this.dataSyncContext;
                cordova.getThreadPool().execute(new Runnable() {
                    public void run() {
                        if (dsc.saveChanges()) {
                            sendResult(Status.OK, "Changes saved in localdatabase.");
                        } else {
                            sendResult(Status.ERROR, "Could not save changes. Reason unknown.");
                        }
                    }
                });
            } else if ("syncChanges".equals(action)) {
                final DataSyncContext dsc = this.dataSyncContext;
                cordova.getThreadPool().execute(new Runnable() {
                    public void run() {
                        try {
                            if (dsc.syncChanges()) {
                                sendResult(Status.OK, "Changes synchronized.");
                            } else {
                                sendResult(Status.ERROR, "Could not sync. Reason unknown.");
                            }
                        } catch (SynchronizationException ex) {
                            sendResult(Status.JSON_EXCEPTION, ex.getMessage());
                        }
                    }
                });
            } else if ("syncModel".equals(action)) {
                final DataSyncContext dsc = this.dataSyncContext;
                cordova.getThreadPool().execute(new Runnable() {
                    public void run() {
                        try {
                            if (syncTable(args)) {
                                sendResult(Status.OK, "Changes synchronized.");
                            } else {
                                sendResult(Status.ERROR, "Could not sync. Reason unknown.");
                            }
                        } catch (SynchronizationException ex) {
                            sendResult(Status.JSON_EXCEPTION, ex.getMessage());
                        } catch (JSONException e) {
                            sendResult(Status.JSON_EXCEPTION, e.getMessage());
                        }
                    }
                });
            } else if ("registerClass".equals(action)) {
                if (registerClass(args)) {
                    sendResult(Status.OK, "Class registered");
                } else {
                    sendResult(Status.ERROR, "Class already registered.");
                }
            } else if ("registerClassAsync".equals(action)) {
                cordova.getThreadPool().execute(new Runnable() {
                    public void run() {
                        try {
                            if (registerClass(args)) {
                                sendResult(Status.OK, "Class registered");
                            } else {
                                sendResult(Status.ERROR, "Class already registered.");
                            }
                        } catch (JSONException ex) {
                            sendResult(Status.JSON_EXCEPTION, ex.getMessage());
                        }
                    }
                });
            } else if ("allObjects".equals(action)) {
                JSONArray objects = this.fetchAllObjects(args);
                sendResult(Status.OK, objects);
            } else if ("queryObjects".equals(action)) {
                JSONArray result = this.queryObjects(args);
                sendResult(Status.OK, result);
            } else if ("updateObject".equals(action)) {
                executeCRUDOperation(UPDATE, args);
                sendResult(Status.OK, "Object updated");
            } else if ("removeObject".equals(action)) {
                executeCRUDOperation(DELETE, args);
                sendResult(Status.OK, "Object removed");
            } else if ("insertObject".equals(action)) {
                executeCRUDOperation(CREATE, args);
                sendResult(Status.OK, "Object Inserted");
            } else {
                sendResult(Status.INVALID_ACTION, "Invalid method called");
                return false;
            }

            return true;
        } catch (JSONException exJSON) {
            sendResult(Status.JSON_EXCEPTION, exJSON.getMessage());
        } catch (NoSuchMethodException exNSM) {
            sendResult(Status.ERROR, exNSM.getMessage());
        } catch (IllegalAccessException exIA) {
            sendResult(Status.ILLEGAL_ACCESS_EXCEPTION, exIA.getMessage());
        } catch (InvocationTargetException exIT) {
            sendResult(Status.ERROR, exIT.getMessage());
        } catch (InstantiationException exInst) {
            sendResult(Status.INSTANTIATION_EXCEPTION, exInst.getMessage());
        }

        return false;
    }

    private void createContext(JSONArray args) throws JSONException {

        JSONObject options = args.getJSONObject(0);

        String localDatabaseName = null;
        if (options.has(LOCAL_DATABASE_PROPERTY_KEY)) {
            localDatabaseName = options.getString(LOCAL_DATABASE_PROPERTY_KEY);
            localDatabaseName = this.cordova.getActivity().getFilesDir() + "/" + localDatabaseName;
        } else {
            throw new JSONException("Local database name is not provided.");
        }

        if (options.has(PROVIDER_PROPERTY_KEY)) {

            CloudClient client = null;
            String providerName = options.getString(PROVIDER_PROPERTY_KEY);
            if (providerName.equals("Everlive")) {
                
                String apiKey = options.getString(API_KEY_PROPERTY_KEY);
                String apiVersion = options.getString(API_VERSION_PROPERTY_KEY);

                //todo: remove this ugly hack ASAP and enable accessToken with username/password
                //String hostName = options.getString(HOSTNAME_PROPERTY_KEY);
                String hostName = "http://api.everlive.com";
                client = new EverliveCloudClient(hostName, apiVersion, apiKey);
            }else {
                try {
                    String username = options.getString(USERNAME_PROPERTY_KEY);
                    String password = options.getString(PASSWORD_PROPERTY_KEY);

                    JSONObject mapping = options
                            .getJSONObject(MAPPING_ARGUMENT_KEY);
                    Iterator<?> keys = mapping.keys();
                    HashMap<String, String> hMappings = new HashMap<String, String>();
                    while (keys.hasNext()) {
                        String key = (String) keys.next();
                        String value = mapping.getString(key);
                        hMappings.put(key, value);
                    }

                    JSONObject typeMapping = options
                            .getJSONObject(TYPE_MAPPING_ARGUMENT_KEY);
                    keys = typeMapping.keys();
                    HashMap<String, String> hTypeMappings = new HashMap<String, String>();
                    while (keys.hasNext()) {
                        String key = (String) keys.next();
                        String value = typeMapping.getString(key);
                        hTypeMappings.put(key, value);
                    }

                    JSONObject systemFieldsMapping = options
                            .getJSONObject(SYSTEM_FIELDS_MAPPING_ARGUMENT_KEY);
                    keys = systemFieldsMapping.keys();
                    HashMap<String, String> hSystemFieldsMappings = new HashMap<String, String>();
                    while (keys.hasNext()) {
                        String key = (String) keys.next();
                        String value = systemFieldsMapping.getString(key);
                        hSystemFieldsMappings.put(key, value);
                    }

                    JSONObject entityPointsMap = options
                            .getJSONObject(MULTIPLE_POINTS_MAP_ARGUMENT_KEY);
                    keys = entityPointsMap.keys();

                    HashMap<String, HashMap<String, String>> hEntityPointsMap = new HashMap<String, HashMap<String, String>>();
                    while (keys.hasNext()) { // Entity Level
                        String key = (String) keys.next();
                        JSONObject entityOperations = entityPointsMap
                                .getJSONObject(key);
                        Iterator<?> operations = entityOperations.keys();
                        HashMap<String, String> opURIs = new HashMap<String, String>();
                        while (operations.hasNext()) {
                            String opKey = (String) operations.next();
                            String uri = entityOperations.getString(opKey);
                            opURIs.put(opKey, uri);
                        }
                        hEntityPointsMap.put(key, opURIs);
                    }

                    ODataCredential credentials = new ODataCredential(username,
                            password);
                    client = new ODataClient(hEntityPointsMap, credentials, 3,
                            hMappings, hTypeMappings, hSystemFieldsMappings);
                } catch (JSONException ex) {
                    throw new JSONException("Wrong options for OData client!");
                }
            }

            if (client != null){ //create synchronization policy
                DataSyncPolicy syncPolicy = new DataSyncPolicy();

                if (options.has(DATA_CONFLICT_RESOLUTION_TYPE_PROPERTY_KEY)) {
                    String conflictRes = options.getString(DATA_CONFLICT_RESOLUTION_TYPE_PROPERTY_KEY);
                    syncPolicy.setDataSyncResolutionType(DataSyncResolutionType.valueOf(conflictRes));
                }

                if (options.has(DATA_SYNC_REACHABILITY_PROPERTY_KEY)) {
                    String reachabilityOptions = options.getString(DATA_SYNC_REACHABILITY_PROPERTY_KEY);
                    syncPolicy.setReachabilityOptions(DataSyncReachabilityOptions.valueOf(reachabilityOptions));
                }

                if (options.has(DATA_SYNC_TIME_INTERVAL_PROPERTY_KEY)) {
                    long syncTimeInterval = options.getLong(DATA_SYNC_TIME_INTERVAL_PROPERTY_KEY);
                    syncPolicy.setSyncTimeInterval(syncTimeInterval);
                }

                if (options.has(DATA_SYNC_TIMEOUT_PROPERTY_KEY)) {
                    long syncTimeout = options.getLong(DATA_SYNC_TIMEOUT_PROPERTY_KEY);
                    syncPolicy.setSyncTimeout(syncTimeout);
                }

                if (options.has(DATA_SYNC_TYPE_PROPERTY_KEY)) {
                    String dataSyncType = options.getString(DATA_SYNC_TYPE_PROPERTY_KEY);
                    syncPolicy.setSyncType(DataSyncType.valueOf(dataSyncType));
                } else {
                    syncPolicy.setSyncType(DataSyncType.DataSyncOnDemand);
                }

                this.dataSyncContext = new DataSyncContext(localDatabaseName, client, syncPolicy, cordova.getActivity().getApplicationContext());
            }
        } else { // create offline context
            this.dataSyncContext = new DataSyncContext(localDatabaseName, null, null, cordova.getActivity().getApplicationContext());
        }

        this.dataSyncContext.setEntityTypeResolver(new EntityTypeResolver() {

            @Override
            public Class resolveType(String arg0) {
                // TODO Auto-generated method stub
                return DataSyncPlugin.this.dynamicClassGenerator.getClassForTypeName(arg0);
            }
        });
        
        this.dataSyncContext.setDataSyncDelegate(this);
    }

    private boolean syncTable(JSONArray args) throws JSONException, SynchronizationException {
        String typeName = null;

        JSONObject propertiesHolder = args.getJSONObject(0);
        if (propertiesHolder.has(ENTITY_NAME_ARGUMENT_KEY)) {
            typeName = propertiesHolder.getString(ENTITY_NAME_ARGUMENT_KEY);
        } else {
            throw new JSONException("The entity name is not provided.");
        }
        return this.dataSyncContext.syncTable(typeName);
    }
    
    private boolean registerClass(JSONArray args) throws JSONException {

        String typeName = null;
        boolean success = false;

        JSONObject propertiesHolder = args.getJSONObject(0);
        if (propertiesHolder.has(ENTITY_NAME_ARGUMENT_KEY)) {
            typeName = propertiesHolder.getString(ENTITY_NAME_ARGUMENT_KEY);
        } else {
            throw new JSONException("The entity name is not provided.");
        }

        if (this.dynamicClassGenerator.getClassForTypeName(typeName) != null) {
            Class registeredClass = this.dynamicClassGenerator.getClassForTypeName(typeName);
            this.registerManagedEntity(propertiesHolder, registeredClass);
            success = true;
        } else {

            JSONObject jsonObject = propertiesHolder.getJSONObject(PROPERTY_VALUES_ARGUMENT_KEY);
            HashMap<String, Class> properties = new HashMap<String, Class>();
            Iterator<?> keysIterator = jsonObject.keys();
            while (keysIterator.hasNext()) {
                String key = (String) keysIterator.next();
                String propertyType = jsonObject.getString(key);
                if (propertyType.equalsIgnoreCase(String.class.getSimpleName())) {
                    properties.put(key, String.class);
                } else if (propertyType.equalsIgnoreCase(Integer.class.getSimpleName())) {
                    properties.put(key, Integer.class);
                } else if (propertyType.equalsIgnoreCase(Boolean.class.getSimpleName())) {
                    properties.put(key, Boolean.class);
                } else if (propertyType.equalsIgnoreCase("number")) {
                    properties.put(key, Float.class);
                }
            }

            TypeInfo ti = new TypeInfo(typeName, properties);
            success = this.dynamicClassGenerator.registerClassForTypeInfo(ti);

            if (success) {
                Class entity = this.dynamicClassGenerator.getClassForTypeInfo(ti);
                this.registerManagedEntity(propertiesHolder, entity);
            }
        }
        return success;
    }

    private void registerManagedEntity(JSONObject propertiesHolder, Class entity) throws JSONException {
        String primaryKeyName = propertiesHolder.getString(PRIMARY_KEY_NAME_ARGUMENT_KEY);
        boolean primaryKeyAutoIncrement = propertiesHolder.getBoolean(PRIMARY_KEY_AUTO_INCREMENT);

        this.dataSyncContext.registerClass(entity, primaryKeyName, primaryKeyAutoIncrement);
    }

    private JSONArray fetchAllObjects(JSONArray args) throws JSONException {
        JSONObject propertiesHolder = args.getJSONObject(0);
        String entityName = propertiesHolder.getString(ENTITY_NAME_ARGUMENT_KEY);
        Class<?> entityType = this.dynamicClassGenerator.getClassForTypeName(entityName);

        ArrayList<Object> result = this.dataSyncContext.getAllObjectsOfType(entityType);
        JSONArray serialized = JSONHelper.toJSONArray(result);

        return serialized;
    }

    private JSONArray queryObjects(JSONArray args) throws JSONException {
        JSONObject propertiesHolder = args.getJSONObject(0);
        String entityName = propertiesHolder.getString(ENTITY_NAME_ARGUMENT_KEY);
        String query = propertiesHolder.getString(QUERY_ARGUMENT_KEY);
        Class<?> entityType = this.dynamicClassGenerator.getClassForTypeName(entityName);

        ArrayList<Object> result = this.dataSyncContext.getObjectsWithQuery(query, null, entityType);
        return JSONHelper.toJSONArray(result);
    }

    private void executeCRUDOperation(int theOperation, JSONArray args) throws JSONException, NoSuchMethodException,
            IllegalAccessException, InvocationTargetException, InstantiationException {

        JSONObject propertiesHolder = args.getJSONObject(0);

        String entityName = null;
        if (propertiesHolder.has(ENTITY_NAME_ARGUMENT_KEY)) {
            entityName = propertiesHolder.getString(ENTITY_NAME_ARGUMENT_KEY);
        } else {
            throw new JSONException("The entity name is not provided.");
        }

        JSONObject entity = null;
        if (propertiesHolder.has(PROPERTY_VALUES_ARGUMENT_KEY)) {
            entity = propertiesHolder.getJSONObject(PROPERTY_VALUES_ARGUMENT_KEY);
        } else {
            throw new JSONException("The property values not provided.");
        }

        Class<?> type = this.dynamicClassGenerator.getClassForTypeName(entityName);
        Object typedInstance = type.newInstance();

        JSONHelper.init(typedInstance, entity, null, null);

        switch (theOperation) {
        case CREATE:
            this.dataSyncContext.insertObject(typedInstance);
            break;
        case UPDATE:
            this.dataSyncContext.updateObject(typedInstance);
            break;
        case DELETE:
            this.dataSyncContext.deleteObject(typedInstance);
            break;
        case READ:
        default:
            throw new NoSuchMethodException("Usupported operation");
        }
    }
    
    @TargetApi(Build.VERSION_CODES.KITKAT)
    private String sendJavascript(final String jsStmt) {

        final CountDownLatch startSignal = new CountDownLatch(1);
        final StringBuilder strRes = new StringBuilder("");
        try {
            webView.post(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        webView.evaluateJavascript(jsStmt,new ValueCallback<String>() {
                                    @Override
                                    public void onReceiveValue(String strReturned) {
                                        strRes.append(strReturned);
                                        startSignal.countDown();
                                    }
                                });
                    } else {
                        webView.loadUrl("javascript:" + jsStmt);
                    }
                }
            });

            startSignal.await();
        } catch (InterruptedException ex) {
            return "";
        }
        
        return strRes.toString();
    }

    @Override
    public boolean beforeSyncOfTableWithName(String tableName) {

        String jsStmt = "(function() { return dataSync.callEventHandle('beforeSynchOfTableWithName','" + tableName + "');})()";
        String strRes = sendJavascript(jsStmt);

        if (strRes.compareTo("true") == 0) {
            return true;
        } else if (strRes.compareTo("\"unregistered\"") == 0) {
            return true;
        }

        return false;
    }

    @Override
    public boolean afterSyncOfTableWithName(String tableName, Exception arg1) {

        String jsStmt = "(function() { return dataSync.callEventHandle('afterSynchOfTableWithName','" + tableName +"');})()";
        String strRes = sendJavascript(jsStmt);

        if (strRes.compareTo("true") == 0) {
            return true;
        } else if (strRes.compareTo("\"unregistered\"") == 0) {
            return true;
        }

        return false;
    }

    @Override
    public boolean dataSyncContextIsReadyForExecution() {

        String strRes = sendJavascript("(function() { return dataSync.callEventHandle('isContextReadyForSynchronization');})()");

        if (strRes.compareTo("true") == 0) {
            return true;
        } else if (strRes.compareTo("\"unregistered\"") == 0) {
            return true;
        }

        return false;
    }

    @Override
    public boolean dataSyncFailedForTableWithName(String tableName, Exception arg1) {

        String jsStmt = "(function() { return dataSync.callEventHandle('dataSyncFailedForTableWithName','" + tableName +"');})()";
        String strRes = sendJavascript(jsStmt);

        if (strRes.compareTo("true") == 0) {
            return true;
        } else if (strRes.compareTo("\"unregistered\"") == 0) {
            return true;
        }

        return false;
    }

    @Override
    public Object resolveConflictOfObjectsWithType(Class type, Object remoteObj, Object localObj) {
        
        String strRemoteJson = "";
        if(remoteObj != null){
            strRemoteJson = getAsJSONString(remoteObj);
        } 

        String strLocalJson = "";
        if (localObj != null){
            strLocalJson = getAsJSONString(localObj);
        }
        
        String jsStmt = "(function() { return dataSync.callEventHandle('resolveConflictOfObjects','" + type.getName() + "','" + strRemoteJson + "','" + strLocalJson + "');})()";
        String strRes = sendJavascript(jsStmt);

        if (strRes.length() > 0) {
            return objectFromJSON(type, strRes);
        } else if (strRes.compareTo("\"unregistered\"") == 0) {
            sendJavascript("(function() { return dataSync.fireHandleError('The resolveConflictOfObjects event is not handled for policy with custom resolution');})()");
            return null;
        }

        return null;
    }
    
    //Reflection helpers
    private String getAsJSONString(Object item ){
        
        CloudEntityMapper mapper = CloudEntityMapper.getInstance();
        HashMap<String, Class> properties = mapper.getEntityProperties(item.getClass());
        HashMap<String, String> propsDict = new HashMap<String, String>();
          
        for (String propertyName : properties.keySet()) {
            propsDict.put(propertyName, getPropertyValueFromObject(item, propertyName).toString());
        }
        
        JSONObject json = new JSONObject();
        for (String propKey : propsDict.keySet()) {
            try {
                json.put(propKey, propsDict.get(propKey));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return json.toString();
    }
    
    private Object objectFromJSON(Class type, String strJson){
        
        CloudEntityMapper mapper = CloudEntityMapper.getInstance();
        HashMap<String, Class> properties = mapper.getEntityProperties(type);
        
        try {
            JSONObject resultObject = new JSONObject(strJson);

              Set<String> keys = properties.keySet();
                for (String propName : keys) {
                    
                    Object targetValue = null;
                    String propVal = (String)resultObject.get(propName);

                    if (type.equals(Calendar.class)) {
                        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.sss'Z'"); //TODO : get this from client :dateTimeFormatPattern
                        Calendar c = Calendar.getInstance();
                        try {
                            c.setTime(format.parse(propVal));
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        targetValue = c;
                    }else if (type.equals(Integer.class) || type.equals(int.class)){
                        targetValue = Integer.valueOf(propVal);
                    }else if (type.equals(Float.class) || type.equals(float.class)){
                        targetValue = Float.valueOf(propVal);
                    }else if (type.equals(Double.class) || type.equals(double.class)){
                        targetValue = Double.valueOf(propVal);
                    }else if (type.equals(Boolean.class) || type.equals(boolean.class)){
                        targetValue = Boolean.valueOf(propVal);
                    }else if (type.equals(UUID.class)){
                        targetValue = UUID.fromString(propVal);
                    }else if (type.equals(String.class)){
                        targetValue = propVal;
                    }

                    if (targetValue != null) {
                        setPropertyOnObject(resultObject, targetValue, propName, properties.get(propName));
                    }
                    
                    return resultObject;
                }
          } catch(JSONException e){
              e.printStackTrace();
          }
        
          return null;
    }
    
    public Object getPropertyValueFromObject(Object source, String propertyName) {
            try {
                
                Method propertyGetter = source.getClass().getDeclaredMethod("get" + propertyName);
                return propertyGetter.invoke(source);
                
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            }catch (InvocationTargetException e) {
                e.printStackTrace();
            }catch (IllegalAccessException e) {
                e.printStackTrace();
            }
            
            return null;            
    }

    public void setPropertyOnObject(Object target, Object propertyValue, String propertyName, Class propertyType) {
        try {
            Method propertySetter = target.getClass().getDeclaredMethod("set" + propertyName, propertyType);
            propertySetter.invoke(target, propertyValue);
            
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
}   
