//
//  TKSecurityClientProtocol.h
//  DataSync
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol TKSecurityClientProtocol <NSObject>

/*!
Authenticates the client & device with username & password.
During this operation a certificate could be downloaded and stored to secure store 
for further usage.
@param registerDevice to register or not the client
@param passPhrase the authentication passphrase for decice
@param error the returned error if any
@result The state of success
*/
- (BOOL)authenticateClient:(BOOL) registerDevice
         withPassPhraseKey:(NSString*)passPhrase
           failedWithError:(NSError**) error;

/*!
 Authenticates the client with PIN relying on already registered certificate
 @param error the returned error if any
 @result The state of success
 */
- (BOOL)authenticateClientWithCertificateAndPIN:(NSError**) error;

- (BOOL)evaluateServerTrust:(SecTrustRef)serverTrustContext
                  forDomain:(NSString *)domain;



- (NSURLCredential*) credentialForAuthentication;

- (NSURLProtectionSpace*)clientCertificateProtectionSpace;

- (NSArray *)validProtectionSpaces ;

@end
