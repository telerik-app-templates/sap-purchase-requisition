//
//  TKSecurityCredentialsProtocol.h
//  DataSync
//
//  Copyright (c) 2015 Telerik. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol TKSecurityCredentialsProtocol <NSObject>

/*!
 Returns builded uri for authentication
 */
-(NSString*) authenticationURI:(BOOL) registerDevice
                withPassPhrase:(NSString*) passPhrase;

/*!
 Returns builded uri for authentication with certificate and PIN
 */
-(NSString*) authenticationURIWithCertificateAndPin;

/*!
 Returns the authentication HTTP method
 */
-(NSString*) authHTTPMethod;
@end