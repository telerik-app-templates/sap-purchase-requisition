//cordova.define("com.telerik.widget.datasync", function(require, exports, module) {
var cordova = require('cordova'),
  DataSync = function() {

    this.isSynced = false;

    this.createOfflineContext = function(options, success, fail) {
      cordova.exec(success, fail, 'DataSync', 'createContext', [options]);
    };

    this.createOfflineContextAsync = function(options, success, fail) {
      cordova.exec(success, fail, 'DataSync', 'createContextAsync', [options]);
    };

    this.createContext = function(options, success, fail) {
      cordova.exec(success, fail, 'DataSync', 'createContext', [options]);
    };

    this.createContextAsync = function(options, success, fail) {
      cordova.exec(success, fail, 'DataSync', 'createContextAsync', [options])
    };

    this.saveChanges = function(success, fail) {
      cordova.exec(success, fail, 'DataSync', 'saveChanges', []);
    };

    this.saveChangesAsync = function(success, fail) {
      cordova.exec(success, fail, 'DataSync', 'saveChangesAsync', []);
    };

    this.syncChanges = function(success, fail) {
      this.isSynced = true;
      cordova.exec(success, fail, 'DataSync', 'syncChanges', []);
    };

    this.syncModel = function(options, success, fail) {
      cordova.exec(success, fail, 'DataSync', 'syncModel', [options]);
    };

    this.registerClass = function(options, success, fail) {
      cordova.exec(success, fail, 'DataSync', 'registerClass', [options]);
    };

    this.registerClassAsync = function(options, success, fail) {
      cordova.exec(success, fail, 'DataSync', 'registerClassAsync', [options]);
    };

    this.addObject = function(options, success, fail) {
      this.isSynced = false;
      cordova.exec(success, fail, 'DataSync', 'insertObject', [options]);
    };

    this.updateObject = function(options, success, fail) {
      this.isSynced = false;
      cordova.exec(success, fail, 'DataSync', 'updateObject', [options]);
    };

    this.deleteObject = function(options, success, fail) {
      this.isSynced = false;
      cordova.exec(success, fail, 'DataSync', 'removeObject', [options]);
    };

    this.allObjects = function(options, success, fail) {
      cordova.exec(success, fail, 'DataSync', 'allObjects', [options]);
    };

    this.objectsWithQuery = function(options, success, fail) {
      cordova.exec(success, fail, 'DataSync', 'queryObjects', [options]);
    };

    this.getUniqueID = function() {
      var d = new Date().getTime();
      d += (parseInt(Math.random() * 100)).toString();
      d = 'uid-' + d;
      return d;
    };

    //events registration
    this._userHandlers = {};

    this.registerHandler = function(type, handler) {
      if (typeof type !== 'string') {
        throw new Error('invalid parameter \'type\'');
      }

      if (typeof handler !== 'function') {
        throw new Error('invalid parameter \'handler\'');
      }

      this._userHandlers[type] = handler;
    };

    this.unregisterHandler = function(type, handler) {
      if (typeof type !== 'string') {
        throw new Error('invalid parameter \'type\'');
      }

      if (typeof handler !== 'function') {
        throw new Error('invalid parameter \'handler\'');
      }

      if (this._userHandlers[type] === handler) {      
        delete this._userHandlers[type];
      }
    };

    this.callEventHandle = function(type, param1, param2) {
      if (typeof type !== 'string') {
        throw new Error('invalid parameter \'type\'');
      }

      if (dataSync._userHandlers[type]) {  
        return dataSync._userHandlers[type](param1, param2);
      } else 
        return "unregistered";
    };
    
    this.fireHandleError = function(errMessage){
      throw new Error(errMessage);
    }
  },
  dataSync = new DataSync();

module.exports = dataSync;
//});